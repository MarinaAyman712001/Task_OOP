﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            this.Text = "Form Test From Form1.cs File";

            InitializeComponent();

            //this.BackColorChanged += Form1_BackColorChanged;

            //this.BackColorChanged += (sender, e) => this.Text = "BackColor Changed";

            this.BackColor = Color.FromArgb(100,200,255);

        }

        //private void Form1_BackColorChanged(object sender, EventArgs e)
        //{
        //    //my Blogic
        //}

        //protected override void OnBackColorChanged(EventArgs e)
        //{
        //    this.Text = "BackColor Changed";
        //    base.OnBackColorChanged(e);
        //}
    }
}
