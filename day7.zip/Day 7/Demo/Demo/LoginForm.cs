﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();

            this.MinimumSize = this.Size;

            //btnOK.Click += BtnOK_Click;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();

            if (txtUserName.Text == "ITI" && txtPassword.Text == "ITI")
            {
                this.Hide();
                form1.ShowDialog();
                this.Visible = true;
                //this.Text = "Login Done";
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            //this.Close();
            Application.Exit();
        }

        private void LoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Are you sure? ",
                "Closing Warning",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2) == DialogResult.No)
                e.Cancel = true;
        }

        //private void Login(object sender, EventArgs e)
        //{

        //}

        //private void BtnOK_Click(object sender, EventArgs e)
        //{
        //    //business login 
        //}
    }
}
