﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextEditor
{
    public partial class CustomForm : Form
    {
        public string Message { get => txtMessage.Text; }
        public CustomForm()
        {
            InitializeComponent();
        }

        private void CustomForm_Load(object sender, EventArgs e)
        {
            this.MinimumSize = this.Size;
        }
    }
}
