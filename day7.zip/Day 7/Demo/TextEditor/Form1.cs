﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextEditor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.MinimumSize = this.Size;
            btnClose.Click += (sender1, e1) => this.Close();
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            dlgOpen.Filter = "Rich Text File|*.rtf|Text File|*.txt";

            if(dlgOpen.ShowDialog() == DialogResult.OK)
            {
                //switch (dlgOpen.FilterIndex)
                //{
                //    case 1:
                //        rtxtInput.LoadFile(dlgOpen.FileName, RichTextBoxStreamType.RichText);
                //        break;
                //    case 2:
                //        rtxtInput.LoadFile(dlgOpen.FileName, RichTextBoxStreamType.PlainText);
                //        break;
                //    default:
                //        break;
                //}

                rtxtInput.LoadFile(dlgOpen.FileName, (RichTextBoxStreamType)dlgOpen.FilterIndex -1);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            dlgSave.Filter = "Rich Text File|*.rtf|Text File|*.txt";
            if (dlgSave.ShowDialog() == DialogResult.OK)
            {
                rtxtInput.SaveFile(dlgSave.FileName, (RichTextBoxStreamType)dlgSave.FilterIndex - 1);
            }
        }

        private void btnFont_Click(object sender, EventArgs e)
        {
            dlgFont.Font = rtxtInput.SelectionFont;

            if (dlgFont.ShowDialog() == DialogResult.OK)
                rtxtInput.SelectionFont = dlgFont.Font;
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            dlgColor.Color = rtxtInput.SelectionColor;

            if (dlgColor.ShowDialog() == DialogResult.OK)
            {
                rtxtInput.SelectionColor = dlgColor.Color;
            }
        }

        private void btnCustom_Click(object sender, EventArgs e)
        {
            CustomForm customForm = new CustomForm();
            if (customForm.ShowDialog() == DialogResult.OK)
            {
                rtxtInput.AppendText(customForm.Message);
            }
        }
    }
}
