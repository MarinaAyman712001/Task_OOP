﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GDIPlus
{
    public partial class NonRect2 : Form
    {
        public NonRect2()
        {
            InitializeComponent();
        }

        private void NonRect2_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;

            GraphicsPath graphics = new GraphicsPath();

            graphics.FillMode = FillMode.Winding;
            graphics.AddEllipse(0, 0, this.Width, this.Height);
            graphics.AddRectangle(new Rectangle(0, 0, 100, 100));

            this.Region = new Region(graphics);
        }
    }
}
