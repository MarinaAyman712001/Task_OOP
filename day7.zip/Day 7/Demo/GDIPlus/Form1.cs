﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GDIPlus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;

            string word = "Hello";
            Font newfont = new Font(new FontFamily("tahoma"), 30);
            SizeF size = graphics.MeasureString(word, newfont);
            Brush brush = new SolidBrush(Color.FromArgb(this.Width%255, this.Height%255, (this.Width + this.Height)%255));

            graphics.DrawString(word, 
                newfont,
                brush, 
                (this.ClientSize.Width-size.Width)/2,
                (this.ClientSize.Height-size.Height)/2);

            base.OnPaint(e);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //this.ResizeRedraw = true;
            this.Resize += (s1, e1) => Invalidate();
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            Graphics graphics = CreateGraphics();
            Pen newpen = new Pen(Color.MidnightBlue, 5);

            graphics.DrawEllipse(newpen, e.X-15, e.Y-15, 30, 30);
            graphics.FillEllipse(Brushes.Moccasin, e.X - 15, e.Y - 15, 30, 30);
        }
    }
}
