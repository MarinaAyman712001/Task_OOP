﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day7Demos
{
    public partial class NewControls : Form
    {

        public NewControls()
        {
            InitializeComponent();
            List<Student> students = new List<Student>();
            students.Add(new Student() { ID = 1, Name = "Mrihan" });
            students.Add(new Student() { ID = 2, Name = "Ahmed" });
            students.Add(new Student() { ID = 3, Name = "Mohamed" });

            listBox1.DisplayMember = "Name";
            listBox1.ValueMember = "ID";
            listBox1.DataSource = students;
        }

        private void Width_Changed(object sender, EventArgs e)
        {
            RadioButton radio = sender as RadioButton;
            if(radio.Checked)
                this.Width = int.Parse(radio.Text);
        }

        private void Height_Changed(object sender, EventArgs e)
        {
            RadioButton radio = sender as RadioButton;
            if(radio.Checked)
                this.Height = int.Parse(radio.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "png|*.png";
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Load(openFileDialog1.FileName);
            }
        }
    }
}
