﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day7Demos
{
    //[Flags]
    //enum TextStyle { bold = 1, italics = 2, underline =4}
    public partial class NewControls2 : Form
    {
        FontStyle style;
        public NewControls2()
        {
            InitializeComponent();
        }

        private void Style_Changed(object sender, EventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            style ^= (FontStyle)(int.Parse(checkBox.Tag.ToString()));
            label1.Font = new Font(label1.Font, style);
        }

        private void trackBar_Scroll(object sender, EventArgs e)
        {
            int red = trackBar1.Value;
            int green = trackBar2.Value;
            int blue = trackBar3.Value;
            label1.ForeColor = Color.FromArgb(red,green,blue);
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            label1.Font = new Font("Tahoma", (float)numericUpDown1.Value);
        }
    }
}
