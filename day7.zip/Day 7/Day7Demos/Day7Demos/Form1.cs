﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day7Demos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CloseBtn.Click += (sender, e) => { this.Close(); };
        }

        private void OpenBtn_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Rich Text File|*.rtf|Plain Text|*.txt";
            var result = openFileDialog1.ShowDialog();
            if(result == DialogResult.OK)
            {
                var type = openFileDialog1.FilterIndex;
                var filePath = openFileDialog1.FileName;
                richTextBox1.LoadFile(filePath, (RichTextBoxStreamType)(type-1));
                //if (type == 1)
                //    richTextBox1.LoadFile(filePath, RichTextBoxStreamType.RichText);
                //else if (type == 2)
                //    richTextBox1.LoadFile(filePath, RichTextBoxStreamType.PlainText);
            }
        }

        private void ColorBtn_Click(object sender, EventArgs e)
        {
            colorDialog1.Color = richTextBox1.SelectionColor;
            var result = colorDialog1.ShowDialog();
            if(result == DialogResult.OK)
            {
                var color = colorDialog1.Color;
                richTextBox1.SelectionColor = color;
            }
        }

        private void FontBtn_Click(object sender, EventArgs e)
        {
            fontDialog1.Font = richTextBox1.SelectionFont;
            var result = fontDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                var font = fontDialog1.Font;
                richTextBox1.SelectionFont = font;
            }
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Rich Text File|*.rtf|Plain Text|*.txt";
            var result = saveFileDialog1.ShowDialog();
            if(result == DialogResult.OK)
            {
                var type = saveFileDialog1.FilterIndex;
                var filePath = saveFileDialog1.FileName;
                richTextBox1.SaveFile(filePath, (RichTextBoxStreamType)(type - 1));
            }
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            AddTextForm textForm = new AddTextForm();
            textForm.InputText = richTextBox1.SelectedText;
            var result = textForm.ShowDialog();
            if (result == DialogResult.OK)
                richTextBox1.AppendText(textForm.InputText);
        }
    }
}
