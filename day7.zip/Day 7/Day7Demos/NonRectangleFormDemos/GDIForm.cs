﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NonRectangleFormDemos
{
    public partial class GDIForm : Form
    {
        public GDIForm()
        {
            InitializeComponent();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;

            string text = "Hello";
            Font font = new Font("Tahoma", 25f);

            var size = graphics.MeasureString(text, font);
            Brush brush = new SolidBrush(Color.FromArgb(255, this.Width%255, this.Height%255));

            graphics.DrawString(text, font, brush, (this.Width-size.Width)/2, (this.Height-size.Height)/2);

            base.OnPaint(e);
        }

        private void GDIForm_Resize(object sender, EventArgs e)
        {
            this.Invalidate();
        }

        private void GDIForm_MouseClick(object sender, MouseEventArgs e)
        {
            Graphics graphics = this.CreateGraphics();

            graphics.DrawEllipse(Pens.Black, e.X-5, e.Y-5, 10, 10);
            graphics.FillEllipse(Brushes.Red, e.X - 5, e.Y - 5, 10, 10);
        }
    }
}
