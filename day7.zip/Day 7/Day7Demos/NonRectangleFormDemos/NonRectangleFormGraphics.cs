﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NonRectangleFormDemos
{
    public partial class NonRectangleFormGraphics : Form
    {
        public NonRectangleFormGraphics()
        {
            InitializeComponent();
        }

        private void NonRectangleFormGraphics_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.BackColor = Color.Red;
            
            GraphicsPath graphicsPath = new GraphicsPath();
            graphicsPath.FillMode = FillMode.Winding;
            graphicsPath.AddEllipse(0, 0, this.Width, this.Height);
            graphicsPath.AddRectangle(new RectangleF(0, 0, 120, 120));

            this.Region = new Region(graphicsPath);
        }
    }
}
